﻿public static class AreaCalculator
    {
        
        public static double CalculateSquareArea(double side)
        {
            if (side <= 0)
            {
                throw new ArgumentException("Сторона квадрата повинна бути додатною.");
            }
            return side * side;
        }

        
        public static double CalculateRectangleArea(double width, double height)
        {
            if (width <= 0 || height <= 0)
            {
                throw new ArgumentException("Ширина та висота повинні бути додатними.");
            }
            return width * height;
        }

        
        public static double CalculateTriangleArea(double a, double b, double c)
        {
            if (a <= 0 || b <= 0 || c <= 0)
            {
                throw new ArgumentException("Усі сторони трикутника повинні бути додатними.");
            }
            
            if (a + b <= c || a + c <= b || b + c <= a)
            {
                throw new ArgumentException("З такими довжинами сторін трикутник не існує.");
            }

            double semiPerimeter = (a + b + c) / 2.0;

            double area = Math.Sqrt(
                semiPerimeter * (semiPerimeter - a) * (semiPerimeter - b) * (semiPerimeter - c)
            );

            return area;
        }
    }
