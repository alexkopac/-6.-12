﻿class Program
{
    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        Console.WriteLine("--- Перевірка DLL-модуля GeometryLibrary ---");

        
        double side = 5.0;
        double squareArea = AreaCalculator.CalculateSquareArea(side);
        Console.WriteLine($"\nПлоща квадрата зі стороною {side}: {squareArea}"); 

        
        double width = 4.0;
        double height = 6.5;
        double rectangleArea = AreaCalculator.CalculateRectangleArea(width, height);
        Console.WriteLine($"Площа прямокутника {width}x{height}: {rectangleArea}"); 

        
        double a = 3.0;
        double b = 4.0;
        double c = 5.0; 
        try
        {
            double triangleArea = AreaCalculator.CalculateTriangleArea(a, b, c);
            Console.WriteLine($"Площа трикутника зі сторонами {a}, {b}, {c}: {triangleArea}"); 
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Помилка при обчисленні трикутника: {ex.Message}");
        }

        Console.WriteLine("\n--- Перевірка успішна! ---");
    }
}